# 阶段一日志包 · 2026-11-06

**只含陈颖旸本机（WSL Ubuntu-22.04，用户 cyy）的阶段一日志**，
不含队友在作品仓库 `logs/stage2/`、`logs/stage3/` 下的 vdot 测试与协同仿真日志。

共 23 个文件，原始 7.08 MB。

## 重点文件

| 需求 | 文件 |
|---|---|
| 最全面（8 小时全程录屏） | `logs/stage1/01-deploy-asciinema.cast`（`asciinema play -s 20` 回放） |
| 纯文本版 | `logs/stage1/01-deploy-asciinema.log` |
| 带时间戳便于定位 | `logs/stage1/01-deploy-asciinema_timed.log` |
| 1.1 验收串 | `logs/stage1/10-hello-final-172031.log` 第 5 行 |
| 1.3 波形/性能数据 | `logs/stage1/vadd-trace.log` |
| vadd 运行结果 | `logs/stage1/vadd-run.log` |
| emu 完整编译 | `logs/stage1/08-make-emu-151840.log` |

## 提醒

1. 转出的 log 含主机名 `LAPTOP-R5BUQPMG` 与 `C:\Users\陈颖旸\...` PATH，对外提交前需脱敏。
2. cast 里 hello 的验收串没显示在被录屏幕上，1.1 视频证据须与
   `10-hello-final-172031.log` 配套引用。
3. 日志为 UTF-8，用 VS Code 打开；记事本会中文乱码。
