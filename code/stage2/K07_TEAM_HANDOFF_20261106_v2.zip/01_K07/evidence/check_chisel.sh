#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
cd "$here/../.."
exec > "$here/chisel_compile.log" 2>&1
cache=/home/cyy/.cache/coursier/v1
cpj=$(find "$cache" -type f -name '*.jar' | paste -sd:)
plugin=$(find "$cache" -name 'chisel-plugin_2.13.15-6.6.0.jar' -print -quit)
out=$(mktemp -d)
java=/opt/graalvm-jdk-21/bin/java
"$java" -version
echo "$plugin"
"$java" -cp "$cpj" scala.tools.nsc.Main -usejavacp -language:reflectiveCalls -Xplugin:"$plugin" -d "$out" implementation/k07_final/chisel/K07.scala
echo PASS
