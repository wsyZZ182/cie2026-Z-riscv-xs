#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
run=${1:?provide a new run directory}
mkdir "$run"
run=$(cd "$run" && pwd)
build=$(mktemp -d)
cd "$root"
exec > >(tee "$run/run.log") 2>&1
trap 'echo "$?" > "$run/exit_code.txt"; date -u +%FT%TZ > "$run/end_utc.txt"' EXIT
date -u +%FT%TZ > "$run/start_utc.txt"
pwd
verilator --version
g++ --version
sha256sum rtl/K07.sv testing/sim.cpp testing/run.sh > "$run/inputs.sha256"
set -x
verilator --cc --exe --build -j 4 --top-module K07 -Wno-fatal --Mdir "$build" "$root/rtl/K07.sv" "$root/testing/sim.cpp"
for seed in {1..18} 20261029 3735928559; do
  "$build/VK07" "$seed"
done
