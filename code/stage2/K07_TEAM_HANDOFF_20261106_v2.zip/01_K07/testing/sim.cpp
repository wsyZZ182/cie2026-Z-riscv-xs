#include "VK07.h"
#include "verilated.h"
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
struct Req {std::array<uint32_t,4>a{},b{}; uint32_t old=0; unsigned sew=0,mask=65535,sign=0,tag=0;};
uint32_t reference(const Req&r) {
  uint32_t sum=r.old; unsigned width=r.sew==0?8:16, lanes=r.sew==0?16:4;
  for(unsigned i=0;i<lanes;i++) if((r.mask>>i)&1) {
    unsigned shift=(i*width)%32, word=i*width/32;
    uint32_t mask=(1u<<width)-1;
    int64_t a=(r.a[word]>>shift)&mask,b=(r.b[word]>>shift)&mask;
    if((r.sign&1)&&(a&(1u<<(width-1))))a-=1u<<width;
    if((r.sign&2)&&(b&(1u<<(width-1))))b-=1u<<width;
    sum+=uint32_t(a*b);
  }
  return sum;
}
struct Bench {
  VK07 d;
  bool occupied=false; uint32_t value=0; unsigned tag=0;
  uint64_t cycles=0,accepted=0,produced=0,cancelled=0,stalls=0,replaced=0,flushes=0,resets=0;
  uint64_t lastAccepted=0,ii1=0,l1=0,highPairs=0;
  uint64_t modes[2][4]{}, masks[4][16]{};
  void check(bool b,const std::string&m){if(!b)throw std::runtime_error("cycle="+std::to_string(cycles)+" "+m);}
  void checkOut(bool valid){check(bool(d.io_out_valid)==valid,"valid mismatch");if(valid){check(d.io_out_bits_result==value,"result expected="+std::to_string(value)+" actual="+std::to_string(d.io_out_bits_result));check(d.io_out_bits_tag==tag,"tag mismatch");}}
  void tick(const Req&r,bool input=true,bool ready=true,bool flush=false,bool reset=false){
    d.clock=0;d.reset=reset;d.io_flush=flush;d.io_in_valid=input;d.io_out_ready=ready;
    for(int i=0;i<4;i++){d.io_in_bits_vs1[i]=r.a[i];d.io_in_bits_vs2[i]=r.b[i];}
    d.io_in_bits_vdOld=r.old;d.io_in_bits_e16=r.sew;d.io_in_bits_mask=r.mask;
    d.io_in_bits_a_signed=r.sign&1;d.io_in_bits_b_signed=(r.sign>>1)&1;d.io_in_bits_tag=r.tag;
    d.eval();
    if(!reset){checkOut(occupied&&!flush);check(bool(d.io_in_ready)==((!occupied||ready)&&!flush),"ready mismatch");}
    bool take=!reset&&input&&d.io_in_ready;
    bool emit=!reset&&d.io_out_valid&&ready;
    if(!reset&&occupied&&!ready&&!flush)stalls++;
    if(flush)flushes++;if(reset)resets++;
    if(reset||flush){if(occupied)cancelled++;occupied=false;}
    else {
      if(emit){produced++;occupied=false;}
      if(take){
        if(emit)replaced++;
        if(accepted&&lastAccepted+1==cycles)ii1++;
        lastAccepted=cycles;accepted++;modes[r.sew][r.sign]++;
        if(r.sew==1)masks[r.sign][r.mask&15]++;
        occupied=true;value=reference(r);tag=r.tag;
      }
    }
    d.clock=1;d.eval();cycles++;
    if(!flush){checkOut(occupied);if(take)l1++;}
    check(accepted==produced+cancelled+unsigned(occupied),"accounting mismatch");
  }
  void run(unsigned seed) {
    std::mt19937 rng(seed);Req r;tick(r,false,true,false,true);tick(r,false);
    unsigned seq=0;
    auto send=[&](Req x){x.tag=seq++&255;tick(x);};
    // Boundary values include zero, all ones, minimum negative, maximum positive,
    // alternating bits and carry/accumulator wrap; every E16 mask in every sign mode.
    const uint32_t patterns[]={0,0xffffffff,0x80008000,0x7fff7fff,0xaaaa5555,0x0100ff00};
    for(unsigned sign=0;sign<4;sign++)for(unsigned mask=0;mask<16;mask++)for(auto p:patterns){
      r=Req{};r.sew=1;r.sign=sign;r.mask=mask;r.old=0xfffffff0;r.a.fill(p);r.b.fill(~p);send(r);
      // Same valid low lanes, perturbed high half and high mask must be irrelevant.
      r.a[2]=rng();r.a[3]=rng();r.b[2]=rng();r.b[3]=rng();r.mask|=0xfff0;send(r);highPairs++;
    }
    for(unsigned sign=0;sign<4;sign++)for(auto p:patterns)for(unsigned mask: {0u,65535u,1u,32768u,0x5555u,0xaaaau}){
      r=Req{};r.sew=0;r.sign=sign;r.mask=mask;r.a.fill(p);r.b.fill(~p);r.old=0xffffffff;send(r);
    }
    // Saturated alternating traffic measures simultaneous consume/replace and II.
    for(unsigned i=0;i<512;i++){r=Req{};r.sew=i&1;r.sign=i&3;r.old=rng();r.tag=seq++&255;for(int j=0;j<4;j++){r.a[j]=rng();r.b[j]=rng();}tick(r);}
    // Directed cancellation while stalled, stable backpressure, and reset cancellation.
    tick(r,false);send(r);for(int i=0;i<5;i++)tick(r,true,false);tick(r,true,false,true);tick(r,false);
    send(r);tick(r,true,false,false,true);tick(r,false);
    for(unsigned i=0;i<10000;i++){
      r=Req{};r.sew=rng()%2;r.sign=rng()%4;r.mask=rng();r.old=rng();r.tag=seq++&255;
      for(int j=0;j<4;j++){r.a[j]=rng();r.b[j]=rng();}
      tick(r,rng()%5!=0,rng()%4!=0,rng()%71==0,rng()%997==0);
    }
    tick(r,false);tick(r,false);
    check(!occupied,"failed to drain");check(stalls&&replaced&&flushes&&resets>1&&highPairs,"missing protocol coverage");
    for(int s=0;s<4;s++){for(int w=0;w<2;w++)check(modes[w][s]>0,"missing sew/sign");for(int m=0;m<16;m++)check(masks[s][m]>0,"missing E16 sign/mask");}
    check(ii1>500&&l1==accepted,"L1/II1 coverage missing");
    std::cout<<"PASS seed="<<seed<<" cycles="<<cycles<<" accepted="<<accepted<<" produced="<<produced<<" cancelled="<<cancelled<<" resident="<<occupied<<" L1_checks="<<l1<<" II1_pairs="<<ii1<<" stalls="<<stalls<<" replace="<<replaced<<" flush="<<flushes<<" reset="<<resets<<" high_half_pairs="<<highPairs<<" E16_sign_mask_bins=64/64 sew_sign_bins=8/8\n";
  }
};
int main(int argc,char**argv){Verilated::commandArgs(argc,argv);try{Bench b;b.run(argc>1?std::stoul(argv[1]):1);return 0;}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
