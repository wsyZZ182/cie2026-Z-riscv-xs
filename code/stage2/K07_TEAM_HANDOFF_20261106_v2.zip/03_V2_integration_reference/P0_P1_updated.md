# K07 × 香山单拍校准：P0 / P1 回传包

日期：2026-11-04。执行方：本机 WSL Ubuntu-22.04（用户 `xiangshan`）。
输入：`K07_XS_CYCLE_FULL_TASKBOOK_20261103.md`（SHA256 `ca52c819…49`）、`K07_XS_CYCLE_HANDOFF_20261103.zip`。
状态更新（2026-11-06）：**P0 = PASS；G1-SOURCE = 冻结为双轨/V-A/B级；KunminghuV2Config 全核 RTL 生成已通过；G1-NETLIST 映射后 Q/D pin 核验仍 NOT_RUN；I轨 P2 = FAIL（E32 vxsat 反例）；候选映射/STA与 P3–P7 = NOT_RUN。** 当前执行在隔离副本 `/home/xiangshan/xs_cycle_work_20261105/XiangShan` 继续，不触碰生产树。

> 未修改生产 RTL、未安装工具。已完成隔离副本 Chisel/Mill 全核 RTL 生成（1,706 个 split modules、48 个 memory models）与 V-A VIAlu/V-Dot RTL 的首轮功能仿真。P2 严格 seed 1 暴露 E32 vxsat 缺陷；20-seed诊断回归确认反复出现，详见 `P2_I_TRACK_20261106.md`。未运行候选综合、映射、布局或 STA；不得报告性能排名。历史 OpenROAD DB round-trip smoke（seed=11）仍仅证明工具能力，不是候选性能测量。
> 所有性能数字均为既有历史报告或明确标记的 smoke 识别信息；无推测性能数字。
> 工作目录：`C:\Users\29125\WorkBuddy AI\AIC\xs_cycle_calibration\`（下称 `$WS`）。

---

## 0. 一页结论

任务书要回答的 5 个问题，当前能推进到哪一步：

| # | 任务书问题 | 本轮状态 | 关键阻塞 |
|---|---|---|---|
| 1 | 香山各级实际做哪些运算、最慢路径在哪 | **源码寄存器段已定位；I轨 K3 为主、O轨 K0/K1 并行** | 生成 RTL后做G1-NETLIST、P2及P4/P5 |
| 2 | K07 相当于参考级多少倍 | **NOT_RUN；双轨分表，不跨语义求比值** | 等P2、G1-NETLIST、P3/P4公平比较 |
| 3 | 目标时钟下单拍是否可行 | **按B级代理相对校准继续；真实频率未知** | 不推断真实香山所需整数拍数 |
| 4 | 若不够，切分边界在哪 | NOT_RUN | 依赖P5逐弧数据 |
| 5 | 继续单拍 / 评估流水 / 保留独立成果 | **依裁决双轨测量、只提交切点方案** | 不改生产流水/ISA；B级先给证据 |

**已执行的 L1 裁决（2026-11-05）：**

1. **双轨分表**：I轨实际集成版 `BWFastTop` 的 E8 路径及真实外围为主；O轨独立优化版 `K07E16x4Top` 的 K0/K1 并行。不同轨不交叉求性能比、不把O轨结果称作整核集成性能。
2. **基准与证据级别**：I轨冻结工作副本 V-A `VDotFu.scala`（含 `k07ResultS2` 和 S2 对齐）；正确性由本轮 P2 验证，不预设 PASS。无真实目标频率材料，按 **B级 ASAP7代理相对校准**继续，不推断真实香山需要 N 拍。
3. **权限/G1拆分**：已授权独立隔离副本中的 Chisel/Mill 展开、等价/功能验证和必要测量；生产 RTL、ISA、正式流水、工具安装/发布仍不在授权范围。G1 分为源码合同 G1-SOURCE 与生成后 pin 核验 G1-NETLIST；允许先生成RTL/映射用于结构调查，未通过 P2/G1-NETLIST 前不发布性能排名。

O轨同时继续历史两项补测：K0/K1 同 full ABC 公平 A/B、以及同一最终实现的完整 SEW 分模式报告。

---

## 1. P0：真正集成 VDot 的版本已定位（含事实更正）

### 1.1 主仓与子模块身份

| 项 | 实测值 |
|---|---|
| 主仓路径 | `/home/xiangshan/projects/xs-env/XiangShan` |
| HEAD | `16ae9ddcda54fc9a2fddffad73174cf793ac7814` |
| branch | `agent/k07-e8-fallback` |
| yunsuan 子模块 HEAD | `cadd3c2f43096e253d61296b33ac697be8354e29` |
| `git status --short` | `M Instructions.scala` / `M VecDecoder.scala` / `M VIPU.scala` / `m yunsuan` |

**更正**：任务书 1.3 引用的历史 HEAD 与 `STATUS.md` 末段"本机整核只读定位（2026-10-29）"记录的正是这个检出，当时确实不含 VDot。但 10-29 之后有人在此检出上完成了整核接入，现在 `rg -i vdot` 在 `src/main/scala` 与 `yunsuan/src/main/scala` 命中 11 个文件。因此**不需要另找"真正集成过 VDot 的版本"，它就是这一个；历史哈希只是同一检出在不同时间的状态**。

### 1.2 未提交改动（高风险，已冻结）

主仓 3 个 tracked 修改（+13 / −1 行）：

| 文件 | SHA256 |
|---|---|
| `src/main/scala/xiangshan/backend/decode/Instructions.scala` | `55099367bab5592df103b678710e534d93c7e6fd216dc486f18ba8d77713c0fb` |
| `src/main/scala/xiangshan/backend/decode/VecDecoder.scala` | `71e35e1ac94e34ed2dae943ad00e595c1529f9bae4071d4aaf78d1ff924bb217` |
| `src/main/scala/xiangshan/backend/fu/wrapper/VIPU.scala` | `8eb5db3888c9d2f318b0030a06b0d377f4c636b76a6d71f1025381f6eb7a7404` |

yunsuan 子模块：4 个 tracked 修改 + 5 个未跟踪新文件（含 `VDotFu.scala`、`vdot/BWFast.scala`、`vdot/BatchConfig.scala`、`vector/vdot/VDotCore.scala`）。

> **风险**：整核接入代码 100% 未提交，任何 `git checkout` / `git clean -fd` / 子模块更新都会直接丢失。
> 已按任务书第 3 节要求把 diff、状态、哈希与**源码本体**全部保存到 `$WS/frozen_diffs/`（`snapshot/` 内 11 个文件 + `SHA256SUMS`），可完整恢复。

### 1.3 竞赛仓库副本存在版本漂移（必须裁决）

`/home/xiangshan/cie2026-Z-riscv-xs` @ `205587f7971abbc457b214b35c84578c29fc126f`（branch `main`）内有 `code/stage2/vdot-rtl/`，是同一批改动的 11 文件副本。逐文件哈希比对：**9 个一致，2 个不一致**。

| 文件 | 工作副本 SHA256（前 12） | 竞赛副本 SHA256（前 12） | 差异性质 |
|---|---|---|---|
| `vdot/BWFast.scala` | `ccd16edfa9cf…` | `7854c3728e30…` | **仅生成选项**：工作副本多 `--disable-layers=Verification` 与一行注释，数据通路不变 |
| `VectorALU/VDotFu.scala` | `018da2fd1e78…` | `488060c09f30…` | **实质差异，寄存器边界不同** |

`VDotFu.scala` 两版差异（见 `$WS/frozen_diffs/` 可读 diff）：

- **竞赛副本（旧）**：K07 结果 `bwfast.io.out.bits.result` 直接经 `MuxLookup(vsew, …)` 组合输出，`dotResult` 无额外寄存；`sew` 传 `io.in.bits.vdType(1,0)`。
- **工作副本（新，含 K07 E8 fallback）**：新增 `k07ResultS2 = RegEnable(k07.io.out.bits.result, k07.io.out.valid)` 一级寄存器；新增 `validS1/coreResultS2/oldVdS2/taS2/vlS2/vstartS2/vsewS2` 一组 S2 寄存器；`sew` 恒 `0.U`。源码注释说明这是修复 back-to-back vdot 指令时"第一条结果配第二条 old_vd，低 32 位对、高 96 位错"的功能 bug。

**结论**：任务书要求"冻结参考和 K07 源哈希"，此处有**两个都真实存在、但寄存器边界不同的集成版本**。必须由总 Agent 指定以哪一个为 R0/K0 基准，否则 P1 边界合同无法冻结、P4 网表身份无法对齐。

### 1.4 原 VDotCore 整核验证记录的绑定状态

`STATUS.md` 与 `3.1-NEMU-vdot-指令扩展与协同仿真验证.md` 记录过 700 用例 DiffTest 等整核验证，但**未找到可把该记录绑定到某个源码哈希的证据**。按任务书 4.1 要求，此项标 **历史证据未绑定（NEEDS_REVIEW）**，不得作为 P2 功能验收依据。

---

## 2. P0：工具与工艺身份（实测）

完整哈希见 `$WS/frozen_diffs/tool_and_pdk.sha256`、版本探测见 `tool_versions.txt`。

| 工具 | 实测版本 / 身份 | 可用性 |
|---|---|---|
| Yosys | `0.70+225 (git sha1 860f20202-dirty, Clang 21.1.8)` | PASS |
| ABC | `UC Berkeley, ABC 1.01 (compiled Oct 27 2026 05:32:14)` | PASS |
| OpenROAD | `-version` 输出 **`OpenROAD unknown`**；Features `-GPU +GUI -Python`；二进制 151,344,696 B，SHA256 `03ca4822453c1df24db42094475b034c86b760da29a741f8f70331d3c8b4187b` | PASS（经 loader 实跑 `-version` 成功） |
| loader | `/home/xiangshan/orfs_root/lib64/ld-linux-x86-64.so.2`，SHA256 `bda779ea9e9a…` | PASS |
| Verilator | **存在两个**：`/usr/local/bin` = 5.048；`oss-cad-suite/bin` = 5.053 devel。**PATH 顺序决定用哪个** | PASS（需冻结 PATH） |
| Java | OpenJDK 17.0.20+8-1-22.04 | PASS |
| mill / firtool | XiangShan 根 `.mill-version=0.12.3`，`mill --version` 实测 0.12.3；yunsuan 子项目 `.mill-version=0.11.1`。firtool 实测 CIRCT 1.62.1 与 1.133.0；绝对路径与哈希记录于 `tool_versions.txt`。本轮**未跑 Chisel 生成**，尚未确认最终选哪版 firtool | PASS（项目版本已测；生成器选择待构建命令冻结） |
| sbt / scala | 不在 PATH（Chisel 生成经 mill）；Java 17.0.20 | NOT_APPLICABLE |
| OpenROAD 功能 smoke | `global_placement` 支持 `-random_seed`；`write_db` / `read_db` 可用；historical BWFastTop 单次 seed=11 DB 往返通过 | PASS（仅命令/数据库能力，不是 timing PASS） |

工艺与单位：

- TT/SS merged Liberty：`335abfa78e3f…` / `623adf0a0c66…`
- `library(asap7sc7p5t_RVT_TT_merged)` 内 **`time_unit : "1ps"`**、`capacitive_load_unit (1,ff)`、`voltage_unit "1V"`、VDD 0.7
- `setRC.tcl` SHA256 `ce6e29fe23b6…`；`make_tracks.tcl` `4693c8fc81cf…`；两个实际使用的 LEF 哈希已记录
- `dont_use` 策略沿用 `{*x1p*_ASAP7* *xp*_ASAP7* SDF* ICG*}`

> **再次确认任务书 1.2 的单位陷阱**：在 1 ps 库下 `set_input_delay 0.050` 是 **0.05 ps**，不是 50 ps。原 `flow_top20_iofix.tcl` 第 35/36 行仍是 0.050；若要建立真实 I/O 预算，必须整体改用显式 ps 数值并在 `constraints_contract.md` 写明单位。

---

## 3. P0：真实目标频率未知 → A 级结论硬阻塞

项目内证据（均在 `/home/xiangshan/cie2026-Z-riscv-xs/docs/`）：

- `description/DECISIONS.md` **D008**：「333.333ps 仅暂定代理对照；不据此宣称 3GHz」「实际 SDC/验收频率仍待冻结」。
- `description/VDot_队友结题指南.md`：「本次查阅的页面没有提供可据以确认的完整评分表、截止日期，**也不能据此认定必须达到 3 GHz**。333.333 ps 只是此前讨论的暂定对照周期；正式目标以团队确认的比赛通知和约束为准。」
- `description/K16_IMPLEMENTATION.md`：「L=1 是周期结构契约，不能据此声称能满足旧 333.333 ps 条件」。
- `docs/stage3/3.4-ASAP7综合与时序结论.md` 里出现的「3 GHz 不达标」是 **ASAP7 代理 STA 的自设对照**，不是芯片签核要求。

这与任务书 4.1「没有则明确'目标频率未知'，不得擅自把 333.333ps/3GHz 当官方要求」完全一致。

**判定**：任务书 10.2 的 **A 级（真实接入条件有依据）当前不可达**；本任务在补齐下列材料前只能交付 **B 级**（同代理工艺相对校准）。需要外部提供：适用芯片代际/工艺角、官方或团队确认的时钟周期、接口 I/O 预算、以及参考级在该频率下的收敛证据。在此之前不得写「K07 需要两拍/三拍」。

---

## 4. P1：真实寄存器边界（源码证据，尚未冻结）

完整逐拍表见 `$WS/boundary_contract.md`。此处给主链路。

### 4.1 调用层级

```
VecDecoder (VDOT_VV -> OPMVV(FuType.vipu, VipuType.vdot_vv))
  -> VIPU (class VIPU extends VecPipedFuncUnit)
       -> VIAluDecoder (VipuType.vdot_vv -> VAluOpcode.vdot)
       -> VIAlu -> VDotFu -> BWFastTop (K07)  [E8]
                          -> VDotCore         [E16/E32]
  -> io.out.bits.res.data := vialu.io.out.bits.vd   (组合直通)
```

`VIPU.scala:151`：`io.out.bits.res.data := vialu.io.out.bits.vd`，VIAlu 数据在 VIPU 内是组合直通。继续向下追到：

- `ExeUnit.scala:371` 的输出数据由 `Mux1H(fuOutValidOH, ...)` 选择，并经 `ExuBlock` 到 `Backend.wbDataPath.io.fromVfExu`（`Backend.scala:667`）。
- `WbArbiter.scala:319–326` 的 vector WB arbiter 选择写回通道；其输出被打包到 `toVfPreg`（`WbArbiter.scala:363–375`）。
- **实际 WB 数据捕获寄存器已定位**：`DataPath.scala:357–359`，`vfRfWaddr := RegEnable(x.addr, x.wen)`、`vfRfWdata := RegEnable(x.data, x.wen)`、`vfRfWen := RegNext(x.wen)`。其中 `vfRfWdata` 宽度为向量数据宽度，供向量物理寄存器文件写入。
- 写入端为 `VfRegFile`（`DataPath.scala:320–322`），底层 `Regfile.scala:85, 118–127` 的 `mem` 为 `Reg(Vec(...))`，经 `Mux1H(wenOH, writePorts.map(_.data))` 在写使能时更新。

所以输出侧真实 reg→reg 路径可追踪为 `VDotFu/VIAlu组合输出 → VIPU → ExeUnit结果选择 → vector WB arbiter → DataPath.vfRfWdata.D`；接着下一阶段将寄存数据写入 `VfRegFile.mem`。此外，`VipuCfg` 为 `CertainLatency(2)`（`FuConfig.scala:600–616`），`VIPU` 的 `HasPipelineReg` 将控制/valid 对齐两级；VIAlu 自身也是 S1/S2 valid 管线。父类 `HasPipelineReg`（`FuncUnit.scala:158–205`）中 ready 沿管线反压、valid 对齐 ROB flush。`GatedValidRegNext`（utility `ClockGatedReg.scala:23–39`）对单 bit 只是 `RegNext(next, init)`，不是条件 clock-gating。

**发射端寄存器也已定位到源码边界**：`Backend.scala:646` 将 `bypassNetwork.io.toExus.vf(i)(j)` 通过命名实例 `bypassNetwork2vfExuBlock` 接到 `vfExuBlock.io.in`；`NewPipelineConnect.scala:40–50` 中 `data = RegEnable(left.bits, left.fire)`，故直接送进 ExeUnit/VIPU 的候选 launch Q 是 `NewPipelineConnectPipe.data`。更上游，`Og2ForVector.scala:30–50` 有 `s2_toExuData` 寄存器，`BypassNetwork.scala:133–174` 对转发/旁路/PRF读取做 `Mux1H`，这些在 `NewPipelineConnectPipe.data` 前完成。**仍待生成 RTL/网表核对该寄存器是否保留、具体 vs1/vs2/vdOld Q pin 与 `BWFastTop.outBits.result` D pin 名称**，因此物理 G1 尚不能冻结。

### 4.2 VIAlu（`VIAlu.scala` 第 45–65 行）

| 级 | 寄存器 | 使能 |
|---|---|---|
| S1 | `vs2Ext = RegEnable(Mux1H(vsew→BitsExtend(vs2…)), io.in.valid)` | `io.in.valid` |
| S1 | `opcodeS1 = RegEnable(io.in.bits.opcode, …)` | `io.in.valid` |
| S1 | `validS1 = RegNext(io.in.valid)` | — |
| S2 | `opcodeS2 = RegEnable(opcodeS1, …)` | `validS1` |
| S2 | `vs2ExtS2 = RegEnable(vs2Ext, …)` | `validS1` |
| 输出 | `vdFinal = Mux(opcodeS2.isVdot, vDotAlu.io.out.vd, Mux(...))` | **组合** |
| 输出 | `io.out.valid = GatedValidRegNext(validS1)` | 寄存器 |

**关键**：valid 契约是两拍（S1、S2），但**输出数据是组合 Mux**。任务书 4.1 问「valid 所谓两拍中每一拍有哪些组合运算」——答案是：S1 锁存操作数/opcode，S2 锁存 opcode 并做输出选择；**算术本身不在 VIAlu 的这两级里，而在 VDotFu/BWFastTop 内部**。不能把「VIAlu 两拍」直接当成「两拍算术预算」。

### 4.3 VDotFu（以工作副本 `018da2fd…` 为准）

| 级 | 内容 |
|---|---|
| S1 | `fire = io.in.valid` 沿锁存 `vm_r / ta_r / vl_r / vstart_r / vsew_r / mask_r / vs1_r / vs2_r / oldVd_r` |
| 组合（当前拍） | K07 输入**取 `io.in.bits` 未锁存值**：16 个 lane 各一个 `Mux(active, vs1/vs2, 0)`，其中 `active = (i < vl) && (vm \|\| mask(i))` |
| S1→S2 | `k07ResultS2 = RegEnable(k07.io.out.bits.result, k07.io.out.valid)` |
| S2 | `validS1 = RegNext(fire)`；`coreResultS2 / coreSatS2 / oldVdS2 / taS2 / vlS2 / vstartS2 / vsewS2` 由 `validS1` 使能 |
| 输出 | `dotResult = Mux(vsewS2===0, Cat(0.U(96.W), k07ResultS2), coreResultS2)` → `redVd` → `tailVd/tailOne` → `tailOut`（组合）→ `io.out.vd` |

### 4.4 BWFastTop（真实 K07，`BWFast.scala` 第 258–289 行）

- 寄存器：`state`(2b) / `saved`(FastRequest) / `p0`,`p1` 各 `Vec(4, GroupPair)` / `acc`(32b) / `outBits`(FastResponse) / `valid`
- `front.req := Mux(state===0.U, io.in.bits, saved)`；`front.second := state===1.U`
- `io.in.ready := state===0.U && (!valid || io.out.ready) && !io.flush`
- **E8：`sew=0` 时 `when(io.in.fire){ outBits.result := Mux(sew===0, front.e8, vdOld); valid := true }` → L=1 / II=1**
- **E16：`sew=1` 时进入 `state=1→2→3` 四状态机 → L=4**（源码注释明确）
- `outBits.result` 的 D 端存在 `when(state===3){outBits.result := merged}` 与 `when(io.in.fire){…}` 的优先级选择，因此 **`state===3` 比较与 `merged` 选择逻辑在 E8 输出寄存器的 D 路径上**（除非综合将其常量优化，需 P4 网表证实）

**阶段解释（按 2026-11-05 裁决）**：`k07ResultS2` 是 BWFastTop 输出的捕获/对齐级，不是把乘法/压缩/CPA拆分出来的算术级。K07的16×BW8、压缩、E8最终加法仍必须在 `BWFastTop.outBits.result.D` 前完成。不能用端到端两级valid宣称算术预算是两拍。

### 4.5 集成视图候选寄存器段（任务书 5.2 主视图；RTL 尚未生成）

**候选算术段**（起点具体 Q 尚未冻结）：

```
[NewPipelineConnectPipe.data Q, instance path bypassNetwork2vfExuBlock]
  -> ExeUnit / VIPU input
  -> VIPU 输入选择 Mux1H(needClearVs1, needShiftVs1, default)
  -> VDotFu 16 × active-Mux (vl / vm / mask)
  -> BWFastTop front.req Mux(state===0, io.in.bits, saved)
  -> SharedBWFrontend: 16 × BW8 -> 4 组 reduce -> finish(join(heaps + word(vdOld)))
  -> Mux(sew===0, front.e8, vdOld)
  -> outBits.result 寄存器 D                      [BWFastTop 内]
```

**候选写回段**：

```
k07ResultS2 Q / aligned S2 regs Q
  -> VDotFu tail 融合 -> VIAlu vdFinal -> VIPU data 直通
  -> ExeUnit result Mux1H -> vector WB arbiter
  -> DataPath.vfRfWdata RegEnable.D
```

之后 `vfRfWdata Q` 与延迟的 write-enable/address 驱动 `VfRegFile.mem D`。这是另一个实际寄存器段，需按与参考相同的 Wb endpoint 分类。

**边界性质**：独立模块 `input→reg` 报告**不能**直接与上述整核 `reg→reg` 路径比较。`DataPath/issue/bypass` 的哪个寄存器 Q 发起当前事务、是否存在 Og2/旁路寄存器，必须从 `NewPipelineConnect` 和生成后网表确认；不得用“VIPU 上游寄存器”泛称代替实际起点。集成视图必须保留上述输入选择、active-Mux、结果选择、WB arbiter 与真实捕获负载，不得为了缩短路径删除。

### 4.6 接口常量化（决定第 5 节结论）

`VDotFu.scala` 工作副本第 ~50 行，K07 端口被这样驱动：

```scala
k07.io.in.bits.a_signed := true.B      // 常量
k07.io.in.bits.b_signed := true.B      // 常量
k07.io.in.bits.sew      := 0.U         // 常量：只有 E8
k07.io.in.bits.mask     := "hffff".U   // 常量：全开（inactive 由前置 Mux 清零）
k07.io.in.bits.tag      := 0.U         // 常量
k07.io.out.ready        := true.B      // 无背压
k07.io.flush            := false.B     // 无 flush
val k07E8Fire = io.in.valid && (io.in.bits.vdType(1,0) === 0.U)
```

E16/E32 走 `VDotCore`，不走 K07。

---

## 5. 关键边界发现：任务书对象与集成对象语义不同（已按双轨裁决分离）

此差异仍是测量设计的核心，但 2026-11-05 L1 已裁决双轨并分表；不再阻塞源码展开/P2。该裁决没有抹平两个对象的功能/外围差异，也不允许跨轨直接求因果比值。

| 维度 | 任务书 1.1 / 7.2 主实验族 B/C/D 的对象 | 真实接入香山的对象（本轮源码证据） |
|---|---|---|
| 顶层 | `K07E16x4Top`（共享版） | `BWFastTop`（`vdot/BWFast.scala`） |
| 结构 | 固定拍数、无状态机、20+12 CPA | **4 状态状态机**：E8 L=1/II=1，**E16 L=4** |
| 符号 | SS/SU/US/UU 动态四种 | `a_signed=b_signed=true.B` **常量** |
| SEW | E8 十六对 / E16 低四对动态切换 | `sew := 0.U` **常量**，仅 E8 |
| mask | 动态 mask、vdOld 融合 | mask 全开常量；inactive 由 VDotFu 前置 16 Mux 清零 |
| tag / flush / 背压 | 完整协议，不得删除 | `tag=0` / `flush=false` / `ready=true`，**协议在接口上未启用** |
| 输出 | 末端输出寄存器 | `outBits` + 额外 `k07ResultS2` 一级 |
| 历史 STA | 动态整体 TT 1949.8518 / SS 2900.4141 ps（full ABC，1000 ps 未收敛） | `BWFastTop` E8 platform_rc_repair TT 1885.3447 / SS 2867.4097 ps（259 FFs，729.95 µm²，见 `3.5` 文档 4.1） |

另有两个相关但不同的独立对象：`K07E8OnlyTop`（窄 E8，TT 1358.0726 / SS 2054.8389 ps，33 FFs，491.89 µm²）与 `K07E8NextTop`（20+12 CPA，TT 1308.2151 / SS 1943.0959 ps）。

项目自己的 `3.5-E8优先修复与三模式STA.md` 第 2 节第 4 条已经写明：「**不同顶层/映射不可直接比**：`BWFastTop` fullABC（259 FFs）与 `K07E16x4Top` fast-map（41 FFs）不是同一设计/状态架构，全局最差路径不能当 E8/E16 模式性能对比」。任务书 1.2 也记录了旧共享版是 fast-map、新版是 full ABC，不能做公平 A/B。

**因此**：

1. 若按任务书原样执行，测出来的是「独立共享优化版 K07E16x4Top 相对香山参考级的延迟」，**不是**「香山里实际跑的那条 K07 路径相对参考级的延迟」。
2. 任务书 1.1 声称的"当前 K07 契约"（四符号、E16 四对、tag/flush/背压）描述的是**独立优化成果**，不是整核集成状态；把它写成接入契约会误导 P7 切点设计与接口影响评估。
3. 任务书问题 5「继续单拍优化 / 评估流水化 / 保留原整核实现并把 K07 作为独立优化成果」这三个选项**恰好对应三个不同对象**，正好说明需要先裁决"这次校准究竟校准哪一个"。

### 曾评估的三个口径（历史备选，已由2026-11-05裁决决断）

| 口径 | 测量对象 | 能回答的问题 | 代价 |
|---|---|---|---|
| **A. 集成现状** | `BWFastTop` E8 路径 + VIPU/VDotFu 集成包装（保留 16 active-Mux、state 逻辑、`k07ResultS2`） | 香山当前这版单拍到底放不放得下 | 最有价值；需 Chisel 生成 RTL + 等价验证；与已有 K07 独立结果无直接继承关系 |
| **B. 独立优化版** | `K07E16x4Top` / `K07E8NextTop`（任务书原口径） | 20+12 CPA 相对收益、四符号/mask 开销 | 可复用已有脚本与结果，但**与整核接入无关**，只能作为独立成果 |
| **C. 双轨** | A + B，分表发布，禁止交叉求比值 | 同时支撑结题的两个方向 | 工作量最大，但符合任务书 5.2「两种视图必须分开」 |

### 已采纳裁决（2026-11-05）

- 采用 **C 双轨分表**：I轨K3 V-A实际整核集成为主，O轨K0/K1独立优化并行。
- I轨采用工作副本 V-A；P2验证正确性，不预判通过。
- B级ASAP7代理结论继续，不等真实频率材料；不外推真实硬件周期。
- 隔离副本Chisel/Mill展开、等价/功能验证与必要测量已获授权。G1分 G1-SOURCE（冻结）和 G1-NETLIST（待映射核验）。
- O轨继续历史K0/K1同full ABC公平A/B及同一最终实现分SEW的补测。
- R0必须从base HEAD干净检出构造；不用带VDot源码作原生参考；不得向R0发新增VDOT opcode。

---

## 6. 关口判定（任务书第 13 节）

| 关口 | 状态 | 依据 / 缺口 |
|---|---|---|
| G0 来源 | **PASS（附条件）** | 主/子仓、工具、库、单位已追踪；Mill/Firtool identities、OpenROAD `-random_seed`/DB smoke已测。OpenROAD版本仍标unknown；实际RTL run仍须固定firtool绝对路径 |
| G1-SOURCE | **FROZEN** | 依据L1 11-05裁决：I/O双轨、V-A基准、B级和隔离Chisel/Mill授权均明确；边界分段见轨合同 |
| G1-NETLIST | **RTL 已生成；映射后 pin 核验 NOT_RUN** | 实际RTL/初映射后核 Q/D pins、enable、位宽、命名/常量传播 |
| G2 I轨正确性 | **FAIL（E32 vxsat 最小反例）** | 修复前验证与完整 VIPU/ExeUnit flush/redirect 覆盖未通过/未完成，见 `P2_I_TRACK_20261106.md` |
| G3 映射 | NOT_RUN | — |
| G4 约束 | NOT_RUN | `constraints_contract.md`按I/O轨冻结前需补端口和负载合同 |
| G5 时序 | NOT_RUN | 不在P2完成前给候选性能排名 |
| G6 可比性 | NOT_RUN | 按双轨分别审查，禁止跨轨比值 |
| G7 结论 | NOT_RUN | B级proxy限界，不宣称真实硅N拍 |

---

## 7. L1裁决与剩余执行检查点

三项策略裁决和执行权限已由 `inputs/K07_XS_P0P1_RULING_20261105.md` 一次性确认，不再待用户选择：

| 项 | 已采纳裁决 | 执行状态 |
|---|---|---|
| 测量范围 | 双轨：I轨实际集成版为主；O轨独立优化并行，分表 | I/O轨合同及实验矩阵已更新 |
| VDotFu | 工作副本 V-A `018da2fd…` | 隔离副本已冻结；正确性仍需P2，不预设PASS |
| 结论等级 | B级ASAP7代理校准 | 333.333ps/1000ps仅作代理点，不外推真实芯片拍数 |
| RTL生成 | 隔离副本Chisel/Mill展开、等价/功能验证已授权 | 正在构建隔离source tree；不改生产树 |
| 历史补测 | O轨K0/K1 full ABC公平A/B；同一最终实现完整SEW分模式 | K0/K1源快照已冻结，待P2与统一flow |

`k07ResultS2` 仅是结果捕获/对齐级。I轨首先检查 `NewPipelineConnectPipe.data.Q → BWFastTop.outBits.result.D`，包含lane清零、乘法/压缩和最终CPA；不能把端到端两级valid说成两拍算术预算。G1-SOURCE已冻结，G1-NETLIST待真实RTL/网表核验。

---

## 8. 本包文件与证据索引

| 文件 | 内容 |
|---|---|
| `P0_P1_HANDBACK_20261104.md` | 本文 |
| `TASKBOOK_REVIEW_20261104.md` | 任务书自身可执行性审查（逐节、含矛盾与建议改法） |
| `source_inventory.md` | 主仓/子模块/竞赛副本清单、commit、dirty 状态、文件哈希 |
| `boundary_contract.md` | P1 寄存器边界逐拍表（输出侧捕获与valid/ready机制已补，BLOCKED 未冻结） |
| `constraints_contract.md` | 约束合同模板（单位、端口方向、例外策略） |
| `decisions.md` | 本轮决策记录 |
| `experiment_matrix.csv` | 实验矩阵骨架（全部 NOT_RUN） |
| `manifest.json` | 冻结清单与状态 |
| `frozen_diffs/xiangshan_tracked.diff` | 主仓 3 文件未提交 diff |
| `frozen_diffs/yunsuan_tracked.diff` | yunsuan 4 文件未提交 diff |
| `frozen_diffs/*status*.txt` / `*head*.txt` / `submodule_status.txt` | 仓库状态快照 |
| `frozen_diffs/snapshot/` | **11 个未提交/新增 XiangShan/yunsuan 源码本体 + SHA256SUMS**，可完整恢复 |
| `frozen_diffs/nemu/` | NEMU HEAD、dirty diff、2 个修改源码本体及哈希，可恢复 |
| `frozen_diffs/context_sources/` | VecPipedFuncUnit、FuncUnit、ExeUnit、Backend、Og2ForVector、BypassNetwork、NewPipelineConnect、WbArbiter、DataPath、Regfile、ClockGatedReg 源码快照 + SHA256SUMS |
| `frozen_diffs/all_vdot_files.sha256` / `yunsuan_untracked.sha256` / `competition_repo.sha256` | 版本漂移比对依据 |
| `frozen_diffs/tool_and_pdk.sha256` / `build_tool_hashes.sha256` / `tool_versions.txt` | 工具、构建链与 PDK 身份 |
| `runs/openroad_probe_20261104/` / `openroad_db_smoke_retry1_20261104/` | OpenROAD seed/DB 命令探测与历史网表的 DB round-trip smoke；不是 K07/香山性能实验 |
| `runs/p1_boundary_trace_20261105/` | issue→Bypass→NewPipelineConnect launch、VIPU latency/valid gate、WB/RF capture source trace；Q/D映射仍需生成 RTL/网表确认 |
| `summary/next_actions.md` | 解除阻塞的最小动作序列 |

**候选性能工作未产出（如实标注）**：没有候选 K07/香山综合网表、布局、STA 报告、性能 `measurements.csv`、逐弧路径归因、共同周期搜索或切点设计；仍不得进行性能排名。已有 P2 功能仿真的 `result.json` 及运行日志不属于性能测量。I轨 P2 首轮已有明确 FAIL 反例，完整 P2 尚未完成；候选映射/STA/P3–P7 仍 NOT_RUN。
