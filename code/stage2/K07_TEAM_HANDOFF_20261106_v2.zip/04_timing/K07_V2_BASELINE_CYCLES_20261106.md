# 昆明湖 V2：E8 原生点积的执行拍数

范围为比赛主仓底本 16ae9ddc 和运算子模块 cadd3c2f 的原生 E8 有符号基线。输入已装在 v0、v1，VL=16，首个累加器为 v4。静态源码核对，不新增实验结果。

|指令|本例拆分|作用|
|---|---:|---|
|vsetvli e8,m1|2 个配置微操作|准备乘法配置，微操作分别服务于整数 rd 和向量 VL|
|vwmul.vv|2 个 VIMAC 微操作 M0、M1|分别生成 v2、v3 两个 128 位的乘积片段|
|vsetvli e16,m2|2 个配置微操作|以两个寄存器为一组读回宽乘结果|
|vwredsum.vs|4 个 VIPU 微操作 R0–R3|R0/R1 分别对 v2/v3 的 8 个半字按高低半组符号扩展、逐对加成四个 32 位部分和。R2 合并两组部分和，R3 横向求和并加旧 v4[0]，输出新 v4[0]|

归约最后一个微操作的第二个向量输入来自 R2，第一个由译码覆盖为累加器，旧目的另用于合并。乘法和归约各微操作均为 CertainLatency(2)，VSET 功能单元 CertainLatency(0)。配置操作还占译码/调度资源。向量配置旁路、乘积中转和各归约微操作之间的依赖应单独对待。两个算术单元在 VFEX0 和 VFEX1，上述配置使用同编号向量写端口。写回预约考虑 OG2，唤醒表和写回表的延迟定义不同。

从 M0 进入乘法单元算 t=0（时钟边沿），纯算术理想排程要求连续接收、生产者两拍后可立即向消费者提供结果、配置就绪，无争用。边沿 t=0/1/2/3/5/7 分别启动 M0/M1/R0/R1/R2/R3，最后结果在 t=9 边沿可用。共九个周期区间。该模型仅描述一个点积的数据依赖，与历史 MinimalConfig 循环平均 3509/500=7.018 拍/点积的测量边界不同。独立点积可重叠，同一累加器也只约束下一点积的最终归约。本次未产生 KunminghuV2Config 的逐拍实测。

[指令译码](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/decode/VecDecoder.scala) · [微操作数](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/decode/UopInfoGen.scala#L175-L230) · [乘法寄存器分配](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/decode/DecodeUnitComp.scala#L484-L497) · [归约依赖](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/decode/DecodeUnitComp.scala#L1499-L1521) · [功能单元延迟](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/fu/FuConfig.scala#L547-L615) · [执行资源](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/Parameters.scala#L448-L449) · [唤醒和写回延迟](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/exu/ExeUnitParams.scala#L166-L225) · [乘法数据通路](https://github.com/OpenXiangShan/YunSuan/blob/cadd3c2f43096e253d61296b33ac697be8354e29/src/main/scala/yunsuan/vector/vectorIMAC/VIMac64b.scala#L164-L220) · [归约数据通路](https://github.com/OpenXiangShan/YunSuan/blob/cadd3c2f43096e253d61296b33ac697be8354e29/src/main/scala/yunsuan/vector/VectorALU/Reduction.scala) · [V2 微架构文档](https://docs.xiangshan.cc/projects/design/en/kunminghu-v2/backend/FunctionUnit/VecFunctionUnit/)
