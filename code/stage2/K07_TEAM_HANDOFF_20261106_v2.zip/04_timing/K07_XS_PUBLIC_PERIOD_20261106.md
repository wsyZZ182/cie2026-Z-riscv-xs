# 昆明湖 V2 原生周期与 K07 证据（2026-11-06 修订）

## 结论

比赛基准限定为昆明湖 V2。回传材料标识的配置为 KunminghuV2Config，主仓 HEAD 为 16ae9ddcda54fc9a2fddffad73174cf793ac7814，工作副本另有补丁。当前无法给出该版本原生整核最慢单周期路径的实测周期，K07 集成版的一拍物理时序待核验。D027 取代 D026，撤回此前按 3.136 ns 推导的一拍结论及演示周期建议。

## 公开与本地证据

- 官方实验仓 XiangShanLab 的 HEAD 源码包也按下列同一文件名筛选规则检查，共 11491 个常规文件、零命中。[官方实验仓](https://github.com/OpenXiangShan/XiangShanLab)
- 源码清单只读核查：官方主仓该提交的源码包有 462 个常规文件，kunminghu-v2 分支本次取得的源码包有 509 个；按文件名匹配 .rpt、.rpt.gz、.sdc、.spef、.odb、.ddc、/sta/、/timing/ 或 report_timing 均为零。该检查覆盖主仓源码包，子模块、发布附件和 CI 产物不在其内。比赛仓默认分支文本检索 report_timing 和 data arrival time 均无命中。[参赛底本](https://github.com/OpenXiangShan/XiangShan/tree/16ae9ddcda54fc9a2fddffad73174cf793ac7814) · [V2 分支](https://github.com/OpenXiangShan/XiangShan/tree/kunminghu-v2)
- 官方入门指南在 V2 提交 6318236 上将 DCache 取数、LoadUnit 选择拼接、唤醒依赖指令列为访存关键路径之一。文章提供逻辑位置，未给出路径时间或整核排名。[官方说明](https://docs.xiangshan.cc/zh-cn/latest/blog/2025/11/06/memory-access-827-2-memory-access-pipeline/)
- 香山 V2 的 7 nm 公开指标与性能评估采用 3 GHz，对应 333.3 ps。进迭时空 V100 产品资料列出的六个昆明湖 V2R2 核工作在 2.1 GHz，对应 476.2 ps。二者都是特定口径下的频率，均无赛事底本的 STA 路径与角条件。[香山团队海报](https://riscv-europe.org/summit/2025/media/proceedings/2025-05-13-RISC-V-Summit-Europe-P2.1.06-TANG-poster.pdf) · [厂商资料](https://spacemit.com/news/2c9c8082a1770faf01a17ccdbbce0000)
- 现有独立 K07 的 ASAP7 原始日志仍可复用。原约束 1000 ps 减单周期 setup slack，专用 E8 的 TT/SS 等效所需周期为 1328.8271/1975.9808 ps，动态共享整体为 1963.6485/2921.6851 ps。证据见 docs/audit-20261029/e8-next-repro-20261101.txt 与 docs/audit-20261029/e8-next-repro-v2-20261101.txt。这些数据覆盖独立模块，不能直接除以商业工艺的周期推断比赛整核的拍数。

## 最少增量工作

优先向执行侧索取已有原生 V2 整核最差同步单周期 setup 报告或已约束的映射后检查点。记录提交/补丁与配置、库与工艺角、分析阶段、实际时钟和路径组、例外、起止寄存器及 slack；若有检查点只补导出报告。若有同口径的 K07 集成切片，再使用该预算检查真实寄存器边界及 setup/hold 覆盖。仅有切片最多可报告该切片的可行周期，全核最慢路径保持待定。比赛同频周期加速比可独立实测。
