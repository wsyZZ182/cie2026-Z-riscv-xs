# 昆明湖 V2 最慢单周期初筛（2026-11-06）

对象为比赛底本 KunminghuV2Config。以下是假设和待测路径。仅做源码及现有 Liberty 表静态读取，未运行 EDA。优先复用现成全核检查点一次导出全部原生同钟、同沿、单周期 setup 路径，按不同捕获端点取前 20。保留跨模块路径，核查例外和未约束端点。只在有切片时缩小结论范围。

|顺序|候选|在网表中查什么|
|---|---|---|
|1|LoadUnit 返数/唤醒|优先查 S2 数据源选择及前递合并到 s3_merged_data_frm_pipe；从该寄存器到 S3 按偏移选择和实际下一级再查一段。数据与唤醒控制分别追寄存器，不把二者串接。官方 V2 文档指出访存关键路径之一；DCache 宏访问须有真实模型。|
|2|StoreQueue 按字节前递到 LoadUnit|查 needCheck0Reg/1Reg 或 data 条目到 parallelFwd 的 priority mux 树，沿输出追最近捕获 D；若与第1项同一路径，仅保留一次。|
|3|VIMAC 宽乘|分别测发射源到 wallaceOut_mid_reg、wallaceOut_mid_reg 到 walOut；动态整体与 E8 合法路径分记。前级为 Booth 加前段 Wallace，后级有最后三级压缩和分段进位。|
|4|VIPU 归约|先查 reg_s1 到 vd_reg 的 32 位预加和压缩，再查 vd_reg 后的末级加法/选择直到真实下一级。作为 K07 的近邻原生参考。|
|5|向量旁路与 SC 预测各一组|宽旁路为生产者数据/选择经两层 Mux1H 到消费端输入寄存器。SC 则查 s2_scTableSums 到 s3_pred_dup 的阈值和方向选择。作为跨区域漏项筛查。|

[LoadUnit](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/mem/pipeline/LoadUnit.scala#L1694-L1745) · [StoreQueueData](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/mem/lsqueue/StoreQueueData.scala#L232-L268) · [VIMAC](https://github.com/OpenXiangShan/YunSuan/blob/cadd3c2f43096e253d61296b33ac697be8354e29/src/main/scala/yunsuan/vector/vectorIMAC/VIMac64b.scala#L145-L209) · [Reduction](https://github.com/OpenXiangShan/YunSuan/blob/cadd3c2f43096e253d61296b33ac697be8354e29/src/main/scala/yunsuan/vector/VectorALU/Reduction.scala#L390-L415) · [BypassNetwork](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/backend/datapath/BypassNetwork.scala#L145-L175) · [SC](https://github.com/OpenXiangShan/XiangShan/blob/16ae9ddcda54fc9a2fddffad73174cf793ac7814/src/main/scala/xiangshan/frontend/SC.scala#L325-L372) · [官方访存说明](https://docs.xiangshan.cc/zh-cn/latest/blog/2025/11/06/memory-access-827-2-memory-access-pipeline/)

## 粗估模型（仅限局部逻辑）

使用 runs/repro_fix_20261030/lib 中的 asap7_rvt_tt_merged.lib 与 asap7_rvt_ss_merged.lib。输入转换时间固定 20 ps；逐级输出电容分别假设全部为 1.44 fF 或全部为 2.88 fF；取每个指定单元 cell_rise/cell_fall 表在该坐标的最大值。Q=DFFHQNx1 的输出时延，N=NAND2xp33，A=AO21x1，X=XOR2xp5。TT 小/大负载 Q,N,A,X 各为 56.7/64.7、29.8/46.7、27.6/32.9、31.9/43.3 ps。SS 各为 82.7/95.8、42.9/70.5、39.5/47.5、46.2/64.8 ps。下表用未舍入数据求和后取整。这是门链的负载敏感性，不是 STA 置信区间或上下界。

|局部逻辑模型|替代链及假设|TT（ps）|SS（ps）|
|---|---|---:|---:|
|SQ 字节选择|Q+15N。按默认56项、两段环形队列共112个逻辑候选估7层二选一，数据穿过每个 MUX 约2层 NAND，加1层控制；映射可能化简。|503–765|726–1154|
|宽乘前级|Q+11X+2N。34个加数经前5层 3:2 压缩到6行；对连续 sum 弧每层按2个 XOR，Booth/部分积入口仅用1X+2N代替。|467–635|677–950|
|归约内部 32 位加法接压缩|Q+4X+10A+2N。假定并行进位映射，约5层组进位每层折2个复杂门，包含加法传播/末位、后续3:2的sum弧及简化选择。映射形状未知。|520–661|749–971|

数值包含模型所选发射触发器 CQ，不含真实布线、SRAM、跨区缓冲、时钟偏斜、捕获 setup 及真实末端负载。多级统一 slew 和假定的门型均会带来误差，尤其无法预测全局最差长线。LoadUnit 总路径不赋一个伪精确数值。结题时替换成同库同角实际 min period 或同钟完整路径的 T − setup slack。

## 同 K07 比较的判据

独立 K07E8NextTop 仅支持有符号、全 mask 的 16 对 E8；sew 固定为零，结果只连 front.e8。K07E16x4Top 才可在 16 对 E8 与低 4 对 E16 间切换。已有独立 E8 折算 setup 所需周期 TT/SS 为 1.329/1.976 ns；动态共享整体为 1.964/2.922 ns。它们可作为拿到 V2 周期后的初筛阈值，不能代替集成同源路径，尤其不得将共享整体最差路径写成 E16 专属。达到数值边界后另查完整集成 setup/hold；超预算的固定单拍逻辑不会自动用下一拍完成。
