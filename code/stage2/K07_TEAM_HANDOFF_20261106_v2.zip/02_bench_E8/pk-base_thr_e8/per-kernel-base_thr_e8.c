#include <am.h>
#include <klib.h>
#include <stdint.h>
#define VDOT_V2 0x12103157u
#define VDOT_V3 0x121031D7u
#define VDOT_V4 0x12103257u
#define VDOT_V5 0x121032D7u
volatile uint64_t g_vres = 0;
static inline uint64_t rdcycle(void) { uint64_t c; asm volatile("rdcycle %0" : "=r"(c)); return c; }
static void enable_vs(void) {
  asm volatile("csrr t0, mstatus\nli t1, 0x600\nor t0, t0, t1\ncsrw mstatus, t0\n" ::: "t0","t1");
}

static void load_data_e8(void) {
  static int8_t a[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
  static int8_t b[16] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
  int vl;
  asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
  asm volatile("vle8.v v0, (%0)" :: "r"(a));
  asm volatile("vle8.v v1, (%0)" :: "r"(b));
}
static uint64_t base_thr_e8(int n) {
  int vl, i; uint64_t s, e;
  load_data_e8();
  asm volatile("vsetvli %0, x0, e32, m1" : "=r"(vl));
  asm volatile("vxor.vv v4, v0, v0"); asm volatile("vxor.vv v5, v0, v0");
  asm volatile("vxor.vv v6, v0, v0"); asm volatile("vxor.vv v7, v0, v0");
  asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
  s = rdcycle();
  for (i = 0; i < n; i += 4) {
    asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
    asm volatile("vwmul.vv v2, v0, v1");
    asm volatile("vsetvli %0, x0, e16, m2" : "=r"(vl));
    asm volatile("vwredsum.vs v4, v2, v4");
    asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
    asm volatile("vwmul.vv v2, v0, v1");
    asm volatile("vsetvli %0, x0, e16, m2" : "=r"(vl));
    asm volatile("vwredsum.vs v5, v2, v5");
    asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
    asm volatile("vwmul.vv v2, v0, v1");
    asm volatile("vsetvli %0, x0, e16, m2" : "=r"(vl));
    asm volatile("vwredsum.vs v6, v2, v6");
    asm volatile("vsetvli %0, x0, e8, m1" : "=r"(vl));
    asm volatile("vwmul.vv v2, v0, v1");
    asm volatile("vsetvli %0, x0, e16, m2" : "=r"(vl));
    asm volatile("vwredsum.vs v7, v2, v7");
  }
  e = rdcycle();
  asm volatile("vsetvli %0, x0, e32, m1" : "=r"(vl));
  uint64_t v = 0; asm volatile("vmv.x.s %0, v4" : "=r"(v)); g_vres = v;
  return e - s;
}

int main(void) {
  enable_vs();
  for (int run = 0; run <= 3; ++run) {
    uint64_t cycles = base_thr_e8(500);
    uint64_t acc[4];
    asm volatile("vmv.x.s %0, v4" : "=r"(acc[0]));
    asm volatile("vmv.x.s %0, v5" : "=r"(acc[1]));
    asm volatile("vmv.x.s %0, v6" : "=r"(acc[2]));
    asm volatile("vmv.x.s %0, v7" : "=r"(acc[3]));
    for (int i = 0; i < 4; ++i) {
      if (acc[i] != 17000) { printf("MISMATCH run=%d acc=%d value=%lu\n", run, i, (unsigned long)acc[i]); return 1; }
    }
    printf("E8,base,%d,500,%lu,CHECK_OK\n", run, (unsigned long)cycles);
  }
  return 0;
}
